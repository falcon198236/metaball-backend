$(function(){


// $(".nav li").click(function(){
  
//   $(".nav li").removeClass("active");
//   $(this).addClass("active");

//   var roomName = $(this).find("a").text();
//   // alert(roomName)

// })
})